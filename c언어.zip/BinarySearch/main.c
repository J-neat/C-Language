#include <stdio.h>
#include <stdlib.h>

struct TreeNode;
typedef int ElementType;
typedef struct TreeNode *Positon;
typedef struct TreeNode *SearchTree;

SearchTree MakeEmpty(SearchTree T);
Position Find(ElementType X, SearchTree T);
Position FindMin(SearchTree T);
Position FindMax(SearchTree T);
SearchTree Insert(ElementType X, SearchTree T);
SearchTree Delete(Element Type X, SearchTree T);
SearchTree Create(ElementType X);

struct TreeNode{
	ElementType Element;
	
	SearchTree Left;//���� �ڽ� ��� 
	SearchTree Right;//������ �ڽ� ��� 
};

Positon Find(ElementType X, SearchTree T){
	if(T==NULL) return NULL;
	else if(X<T->Element) return Find(X, T->Left);
	else if(X>T ->Element) return Find(X, T->Right);
	else return T;

}

Position FindMin(SearchTree T)
{
	if(T==NULL) return NULL;
	else if(T->Left == NULL) return T;
	else return FindMin(T->Left);
}

Position FindMax(SearchTree T)
{
	if(T==NULL) return NULL;
	else if(T->Right == NULL) return T;
	else return FindMax(T->Right);
}

SearchTree Insert(ElementType X, SearchTree T)
{
	if(T==NULL){
		T = (SeachTree)malloc(sizeof(struct TreeNode));
		T->Element = X;
		T->Left = NULL;
		T->Right = NULL;
	}else if(X<T->Element){
		T->Left = Insert(X, T->Left);
	}else if(X>T->Element){
		T->Right = Insert(X, T->Right);
	}
	return T;
}

SearchTree Create(ElementType X)
{
	SearchTree Tmp;
	Tmp = (SearchTree)malloc(sizeof(struct TreeNode));
	Tmp->Element = x;
	Tmp->Left = NULL;
	Tmp->Right = NULL;
	return Tmp;
}
int main()
{
	SearchTree T;
	//6-2-8-1-4-3
	T = Create(6);
	Insert(2, T);
	Insert(8, T);
	Insert(1, T);
	Insert(4, T);
	Insert(3, T);
	
	printf("%d", T->Elements);
	printf("%d", T->Left->Element);
	printf("%d", T->Right->Element);
	
	return 0;
}


