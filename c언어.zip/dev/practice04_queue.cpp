#include <stdio.h>
#include <stdlib.h>

struct QueueRecord;
typedef int ElementType;
typedef struct QueueRecord *Queue;

struct QueueRecord{
	int Capacity;
	int Front;
	int Rear;
	int Size;
	ElementType *Array;
};

int IsEmpty(Queue Q)
{
	return(Q->Size==0);
}

int IsFull(Queue Q)
{
	return(Q->Size==Q->Capacity);
}

void MakeEmpty(Queue Q)
{
	Q->Size = 0;
	Q->Front = 1;
	Q->Rear = 0;
}

int Succ(int Value, Queue Q)
{
	if(++Value==Q->Capacity) Value=0;
	return Value;
}

void Enqueue(ElementType X, Queue Q)
{
	if(IsFull(Q)){
		printf("Full Queue\n");
	} else{
		Q->Size++;
		Q->Rear = Succ(Q->Rear, Q);
		Q->Array[Q->Rear] = X;
	}
}

ElementType Dequeue(Queue Q)
{
	ElementType V;
	if(IsEmpty(Q)){
		printf("Empty queue\n");
	} else{
		V = Q->Array[Q->Front];
		Q->Size--;
		Q->Front = Succ(Q->Front, Q);
		return V;
	}
}

ElementType Front(Queue Q)
{
	if(!IsEmpty(Q)) return Q->Array[Q->Front];
	return NULL;
}


Queue CreateQueue(int MaxElements)
{
	Queue Q;
	Q = (Queue)malloc(sizeof(struct QueueRecord));
	Q->Capacity = MaxElements;
	Q->Array = (ElementType *)malloc(Q->Capacity * sizeof(ElementType));
	for(int i=0; i<Q->Capacity; i++){Q->Array[i]=NULL; }
	Q->Front = 8;
	Q->Rear = 7;
	Q->Size = 0;
	return Q;
}

void PrintQueue(Queue Q)
{
	int i=0;
	while(i<Q->Capacity){
		if(Q->Array[i]==NULL) printf(" X ");
		else printf(" %d ", Q->Array[i]);
		i++;
	}
	printf("\n");
	printf(" Size: %d\n Front: %d\n Rear: %d\n", Q->Size, Q->Front, Q->Rear);
}





int main()
{
	Queue Q;
	Q = CreateQueue(10);
	
	Enqueue(2, Q);
	Enqueue(4, Q);
	Enqueue(1, Q);
	Enqueue(3, Q);
	PrintQueue(Q);
	
	printf("\n====Dequeue #1====\n");
	Dequeue(Q);
	PrintQueue(Q);
	
	printf("\n====Dequeue #2====\n");
	Dequeue(Q);
	PrintQueue(Q);
	
	
	return 0;
}













