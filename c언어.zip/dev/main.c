typedef TreeNode;
typedef struct TreeNode *Position;
typedef struct TreeNode *SearchTree;

SearchTree MakeEmpty(SearchTree T);
Position Find(ElementType X, SearchTree T);
Position FindMin(SearchTree X);
Position FindMax(SearchTree X);
SearchTree Insert(ElementType X, SearchTree T);
SearchTree Delete(Element Type X, SearchTree T);

struct TreeNode
{
	ElementType Element;
	SearchTree Left;
	SearchTree Right;
};

SearchTree MakeEmpty(SearchTree T)
{
	if(T != NULL){
		MakeEmpty(T->Left);
		MakeEmpty(T->Right);
		free(T);
	}
	return NULL;
}

Position Find(ElementType X, SearchTree T)
{
	if(T = NULL) return NULL;
	else if(X<T->Element)return Find(X, T->Left);
	else if(X>T->Element)return Find(X, T->Right);
	else return T;
}
Position FindMin(SearchTree T)
{
	if(T ==NULL) return NULL;
	else if(T->Left == NULL) return T;
	else return FindMin(T->Left);
}

Position FindMax(SearchTree T)
{
	if(T == NULL) return NULL;
	else if(T->Right = NULL) return NULL;
	else return FindMax(T->Right);
}

SearchTree Insert(ElementType X, SearchTree T)
{
	if(T = NULL){
		T = (SearchTree)malloc(sizeof(struct TreeNode));
		if(T = NULL) FetalError("Out of Memory");
		else{
			T->Element = X;//NULL�� �ƴҰ�� ���� X�� ��Ʈ ��尡 �� 
			T->Left = T->Right = NULL;
		}
	}else if(X <T->Element){
		T->Left = Insert(X, T->Left);
	}else if(X >T->Element){
		T->Right = Insert(X, T->Right);
	}
	return T;
}
SearchTree Delete(ElementType X, SearchTree T)
{
	if(T == NULL){//do nothing
	}else if(X<T->Element){//�ڽ� ��� �ϳ� 
		T->Left = Delete(X, T->Left);
	}else if(X>T->Element){
		T->Right = Delete(X, T->Right);
	}else if(T->Left && T->Right){//�ڽ� ��� �� 
		Tmp = FindMin(T->Right);//�ּڰ� ã��
		T->Element = Tmp->Element;
		T->Right = Delete(T->Element, T->Right);//�����ʿ��� �ּڰ� ���� 
	}else{//�ڽ� �ϳ� Ȥ�� ���� 
		Tmp = T;
		if(T->Left == NULL) T = T->Right;
		else if(T->Right == NULL) T = T->Left;
		free(Tmp);
	}
	return T;
}
