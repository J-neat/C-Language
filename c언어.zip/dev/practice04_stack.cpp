#include <stdio.h>
#include <stdlib.h>

struct Node;
typedef int ElementType;
typedef struct Node *PtrToNode;
typedef PtrToNode Stack;

struct Node{
	ElementType Element;
	PtrToNode Next;
};



Stack CreateStack(void)
{
	Stack S;
	S = (Stack)malloc(sizeof(struct Node));
	S->Next = NULL;
	return S;
}

void Push(ElementType X, Stack S)
{
	PtrToNode Tmp;
	Tmp = (PtrToNode)malloc(sizeof(struct Node));
	Tmp->Element = X;
	Tmp->Next = S->Next;
	S->Next = Tmp;
}

ElementType Pop(Stack S)
{
	PtrToNode Tmp = S->Next;
	ElementType V;
	if(Tmp==NULL){
		printf("Empty stack\n");
	} else{
		V = Tmp->Element;
		S->Next = Tmp->Next;
		free(Tmp);
	}
	return V;
}


ElementType Top(Stack S)
{
	if(S->Next) return(S->Next->Element);
	else {return NULL;}
}


void PrintStack(Stack S)
{
	PtrToNode Tmp=S->Next;
	while(Tmp!=NULL){
		printf(" %d ", Tmp->Element);
		Tmp = Tmp->Next;
	}
	printf("\n");
}


int main()
{
	Stack S;
	S = CreateStack();
	
	Push(9, S);
	Push(4, S);
	Push(5, S);
	Push(2, S);
	Push(1, S);
	PrintStack(S);
	
	ElementType V;
	Pop(S);
	V = Pop(S);
	printf("\n%d was popped\n", V);
	
	PrintStack(S);
	
	
	
	return 0;
}
















