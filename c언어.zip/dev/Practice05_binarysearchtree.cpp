#include<stdio.h>
#include<stdlib.h>

struct TreeNode;
typedef int ElementType;
typedef struct TreeNode *Position;
typedef struct TreeNode *SearchTree;



Position Find(ElementType X, SearchTree T);
Position FindMin(SearchTree T);
Position FindMax(SearchTree T);
SearchTree Insert(ElementType X, SearchTree T);
SearchTree Delete(ElementType X, SearchTree T);
SearchTree Create(ElementType X);


struct TreeNode{
	ElementType Element;
	SearchTree Left;
	SearchTree Right;
};


Position Find(ElementType X, SearchTree T)
{
	if(T==NULL) return NULL;
	else if(X<T->Element) return Find(X, T->Left);
	else if(X>T->Element) return Find(X, T->Right);
	else return T;
}

Position FindMin(SearchTree T)
{
	if(T==NULL) return NULL;
	else if(T->Left==NULL) return T;
	else return FindMin(T->Left);
}

Position FindMax(SearchTree T)
{
	if(T==NULL) return NULL;
	else if(T->Right==NULL) return T;
	else return FindMax(T->Right);
}

SearchTree Insert(ElementType X, SearchTree T)
{
	if(T==NULL){
		T=(SearchTree)malloc(sizeof(struct TreeNode));
		T->Element = X;
		T->Left = NULL;
		T->Right = NULL;
	} else if(X<T->Element){
		T->Left = Insert(X, T->Left);
	} else if(X>T->Element){
		T->Right = Insert(X, T->Right);
	}
	return T;
}

SearchTree Create(ElementType X)
{
	SearchTree Tmp;
	Tmp = (SearchTree)malloc(sizeof(struct TreeNode));
	Tmp->Element = X;
	Tmp->Left = NULL;
	Tmp->Right = NULL;
	return Tmp;
}

SearchTree Delete(ElementType X, SearchTree T)
{
	Position Tmp;
	if(T==NULL){
	} else if(X<T->Element){
		T->Left = Delete(X, T->Left);
	} else if(X>T->Element){
		T->Right = Delete(X, T->Right);
	} else if(T->Left && T->Right){
		Tmp = FindMin(T->Right);
		T->Element = Tmp->Element;
		T->Right = Delete(T->Element, T->Right);
	} else{
		Tmp = T;
		if(T->Left==NULL) T = T->Right;
		else if(T->Right==NULL) T = T->Left;
		free(Tmp);
	}
	return T;
}





int main()
{
	SearchTree T;
	// 6-2-8-1-4-3
	T = Create(6);
	Insert(2, T);
	Insert(8, T);
	Insert(1, T);
	Insert(4, T);
	Insert(3, T);
	
	printf("%d ", T->Element);
	printf("%d ", T->Left->Element);
	printf("%d ", T->Right->Element);
	printf("%d ", T->Left->Left->Element);
	printf("%d ", T->Left->Right->Element);
	printf("%d ", T->Left->Right->Left->Element);
	
	Delete(2, T);
	printf("\n\n");
	printf("%d ", T->Element);
	printf("%d ", T->Left->Element);
	printf("%d ", T->Right->Element);
	printf("%d ", T->Left->Left->Element);
	printf("%d ", T->Left->Right->Element);




	
	return 0;
}










