﻿// tree.c

#include <stdio.h>
#include <stdlib.h>

typedef struct treeNode {//트리노드 노드 생성
    int key;//입력 값
    struct treeNode* left;//왼쪽 서브트리
    struct treeNode* right;//오른쪽 서브트리
}treeNode;

treeNode* insert(treeNode* p, int num)//p가 가리키는 노드와 비교하여 num을 삽입
{
	treeNode* newNode;
	if (p == NULL) {
		newNode = (treeNode*)malloc(sizeof(treeNode));//동적 할당
		newNode->key = num;
		newNode->right = NULL;
		newNode->left = NULL;

		return newNode;
	}
	else if (num < p->key) p->left = insert(p->left, num);//작으면 왼쪽 서브트리
	else if (num > p->key) p->right = insert(p->right, num);//크면 오른쪽 서브트리

	return p;
}
void printTree(treeNode* root) {//전위 순회 방식
	if (root) {
		printf("%d ", root->key);
		printTree(root->left);
		printTree(root->right);
	}
}

